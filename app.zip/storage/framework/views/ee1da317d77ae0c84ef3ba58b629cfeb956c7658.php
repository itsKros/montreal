<?php $__env->startSection('content'); ?>
<div class="page-wrapper" style="min-height: 294px;">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Welcome To Monteral Gentleman CMS</h3>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                
                <div class="row price">
                    <div class="col-12">
                        <?php echo $__env->make('frontend.msgs.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <h3 class="m-b-0">Packages </h3>
                        <p class="text-muted m-t-0 font-12">
                            Edit packages rate
                        </p>
                    </div>
                    <form action="<?php echo e(route('package.update', ['package' => 1])); ?>" method="POST" class="form-horizontal form-material row">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <!--One Hour Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">One Hour Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="onehour">Add Price <small>(in CAD)</small></label>
                                        <input type="text" id="onehour" name="onehour" value="<?php echo e($package->onehour); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--One Hour Ends-->


                        <!--For Hour Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">Three Hours Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="threehour">Add Price <small>(in CAD)</small></label>
                                        <input type="text" id="threehour" name="threehour" value="<?php echo e($package->threehour); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--Four Hour Ends-->

                        <!--For Eight Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">Eight Hours Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="eighthour">Add Price <small>(in CAD)</small></label>
                                            <input type="text" id="eighthour" name="eighthour" value="<?php echo e($package->eighthour); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--Four Eight Ends-->

                        <!--For twentyfour Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">24 Hours Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="twentyfourhour">Add Price <small>(in CAD)</small></label>
                                            <input type="text" id="twentyfourhour" name="twentyfourhour" value="<?php echo e($package->twentyfourhour); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--Four Eight Ends-->

                        <!--For Weekend Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">Weekend Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="weekend">Add Price <small>(in CAD)</small></label>
                                            <input type="text" id="weekend" name="weekend" value="<?php echo e($package->weekend); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--Four Weekend Ends-->

                        <!--For Week Start-->
                        <div class="col-md-4 package">
                            <div class="card card-outline-inverse">
                                <div class="card-header">
                                    <h4 class="m-b-0 text-white">Week Rate</h4></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label for="week">Add Price <small>(in CAD)</small></label>
                                            <input type="text" id="week" name="week" value="<?php echo e($package->week); ?>" class="form-control form-control-line">
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <!--Four Week Ends-->
                    
                        <div class="col-sm-6">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <button class="btn btn-inverse btn-md">Update</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montreal\resources\views/backend/packages/index.blade.php ENDPATH**/ ?>