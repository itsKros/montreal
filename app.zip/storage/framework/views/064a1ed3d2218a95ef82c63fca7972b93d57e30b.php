<?php $__env->startSection('content'); ?>
<div class="page-wrapper" style="min-height: 294px;">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-12 align-self-center">
                <h3 class="text-themecolor m-b-0 m-t-0">
                    <?php if($user->status == 0): ?>
                    <form action="<?php echo e(route('user.status_approve', ['user'=>$user->id])); ?>" method="POST" style="float: left;">
                        <?php echo e(csrf_field()); ?>

                        
                        <input type="submit" class="btn btn-primary" value="Approve"/>
                    </form>
                    <?php elseif($user->status == 1): ?>
                    <form action="<?php echo e(route('user.status_disapprove', ['user'=>$user->id])); ?>" method="POST" style="float: left;">
                        <?php echo e(csrf_field()); ?>

                        
                        <input type="submit" class="btn btn-success" value="Disapprove"/>
                    </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger" style="float:right;">Go Back</a></h3>
            </div>
        </div>
        <?php echo $__env->make('frontend.msgs.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row el-element-overlay">
            
            <div class="col-lg-3">
                <div class="card">
                    <div class="el-card-item">
                        <div class="el-card-avatar el-overlay-1"> 
                            <img src="/public/uploads/avatars/<?php echo e($user->avatar); ?>" alt="<?php echo e($user->name); ?>">
                        </div>
                        <div class="el-card-content">
                            <p>
                                <?php if($user->status == 1): ?>
                                    <span class="label label-primary">Approved</span>
                                <?php elseif($user->status == 0): ?>
                                    <span class="label label-danger">Not approved</span>
                                <?php endif; ?>
                            </p>
                            <h3 class="box-title"><?php echo e($user->name); ?></h3> <small><?php echo e($user->email); ?></small>
                            <br> 
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-body">
                            <form action="<?php echo e(route('userprofiledetailchange',['user' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    
                                <div class="row">
                                    <div class="col-md-3">
                                        <h4>Featured Image</h4>
                                        <img src="/public/uploads/featuredimages/<?php echo e($user->featuredimage); ?>" alt="<?php echo e($user->name); ?>" class="userfeatured img-responsive"/>
                                        <input type="file" class="form-control" id="featuredimage" name="featuredimage"">
                                    </div>
                                    <div class="col-md-9">
                                        <h4>Description</h4>
                                        <div class="desc">
                                            <textarea class="form-control form-control-line" name="modeldetail" id="modeldetail"><?php echo e($user->modeldetail); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12" style="height:30px;"></div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="height" class="control-label">Height</label>
                                            <input type="text" class="form-control" id="height" name="height" placeholder="Enter height" value="<?php echo e($user->height); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="weight" class="control-label">Weight</label>
                                            <input type="text" class="form-control" id="weight" name="weight" placeholder="Enter weight" value="<?php echo e($user->weight); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="age" class="control-label">Age</label>
                                            <input type="text" class="form-control" id="age" name="age" placeholder="Enter Age" value="<?php echo e($user->age); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="haircolor" class="control-label">Hair Color</label>
                                            <input type="text" class="form-control" id="haircolor" name="haircolor" placeholder="Enter Hair Color" value="<?php echo e($user->hair_color); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="eyecolor" class="control-label">Eyes Color</label>
                                            <input type="text" class="form-control" id="eyecolor" name="eyecolor" placeholder="Enter Eye Color" value="<?php echo e($user->eye_color); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group col-12">
                                        <input type="submit" class="btn btn-primary kbtn" value="Udpate">
                                    </div>
                                </div>
                            </form>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <h4>Gallery</h4>
                            </div> 
                        
                            <?php if(count($galleryitems) > 0): ?>
                                <?php $__currentLoopData = $galleryitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="gall-thumb">
                                            <form action="<?php echo e(route('gallerydestroy', ['id'=>$galleryitem->id])); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <button class="btn btn-danger btn-xs" type="submit"><i class="fas fa-times"></i></i></button>
                                            </form>
                                            <img src="/public/uploads/galleries/<?php echo e($galleryitem->galleryitem); ?>" alt="" class="img-responsive thumb"/>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-md-3">
                                    No gallery images
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
   

           
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/4.11.4/basic/ckeditor.js"></script>
<script>
CKEDITOR.replace( 'modeldetail' );

</script>

<?php $__env->stopSection(); ?>
           
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montreal\resources\views/backend/user/show.blade.php ENDPATH**/ ?>