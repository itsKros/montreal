<?php $__env->startSection('content'); ?>
    <div class="page-wrapper" style="min-height: 294px;">
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-12 align-self-center">
                    <h3 class="text-themecolor m-b-0 m-t-0">Edit Testimonial<a href="<?php echo e(route('testimonial.index')); ?>" class="btn btn-danger" style="float:right;">Go Back</a></h3>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="row">

                <div class="col-lg-12">
                    <?php echo $__env->make('frontend.msgs.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <form action="<?php echo e(route('testimonial.update', ['id' => $testimonial->id])); ?>" enctype="multipart/form-data" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('PUT')); ?>

                                        <img src="/uploads/testimonials/<?php echo e($testimonial->author_img); ?>" alt="<?php echo e($testimonial->author_name); ?>" class="userfeatured"/>
                                        <br>
                                        <div class="form-group">
                                            <label for="author_img">Author Image</label>
                                            <input type="file" class="form-control form-control-line" name="author_img" id="author_img">
                                        </div>
                                        <div class="form-group">
                                            <label for="author_name">Author Name</label>
                                            <input type="text" class="form-control form-control-line" name="author_name" id="author_name" placeholder="Enter Author Name" value="<?php echo e($testimonial->author_name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="author_desig">Author Designation</label>
                                            <input type="text" class="form-control form-control-line" name="author_desig" id="author_desig" placeholder="Enter Author Designation" value="<?php echo e($testimonial->author_desig); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="desc">Description</label>
                                            <textarea class="form-control form-control-line" name="desc" id="desc" placeholder="What they says.."><?php echo e($testimonial->desc); ?></textarea>
                                        </div>



                                        <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Submit</button>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montreal\resources\views/backend/testimonial/edit.blade.php ENDPATH**/ ?>