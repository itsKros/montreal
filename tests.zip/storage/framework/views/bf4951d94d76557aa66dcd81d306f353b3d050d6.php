        <!-- footer section start -->
		<footer class="re-footer-section">
			<!-- footer-top area start -->
			<div class="footer-top section-padding-top">
				<div class="footer-dsc">
					<div class="container">
						<div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="single-text res-text">
                                    <div class="footer-title">
                                        <h4>About Montreal Gentleman</h4>
                                        <hr class="dubble-border"/>
                                    </div>
                                    <div class="footer-text">
                                        <p>
                                           Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
                                           Aspernatur non quas necessitatibus neque facere! Excepturi cupiditate illo, 
                                           vero nostrum totam necessitatibus quam quaerat ex illum tenetur sunt nemo veniam deleniti!
										</p>
										<p>
                                                Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
                                                Aspernatur non quas necessitatibus neque facere! Excepturi cupiditate illo, 
                                                vero nostrum totam necessitatibus quam quaerat ex illum tenetur sunt nemo veniam deleniti!
                                             </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 hidden-sm col-md-3 margin-top">
                                <div class="single-text res-text">
                                    <div class="footer-title">
                                        <h4>Join us</h4>
                                        <hr class="dubble-border"/>
                                    </div>
                                    <div class="footer-text">
                                        <p>Lorem ipsum dolor sit amet, consectetures do adipisicing elit, sed do eiusmod tempores incididunt ut labore</p>
										<p>
											<a class="btn btn-primary" href="<?php echo e(route('contact')); ?>">Recruitment</a>
										</p>
										
										
                                    </div>
                                </div>
                            </div>
							<div class="col-xs-12 col-sm-4 col-md-3">
								<div class="single-text res-text">
									<div class="footer-title">
										<h4>Contact us</h4>
										<hr class="dubble-border"/>
									</div>
									<div class="footer-text">
										<ul>
											<li class="femail">
												<i class="pe-7s-mail-open"></i>
												<div class="email">
													<p>info@montrealgentleman.com</p>
													<p>montrealgentleman@outlook.com</p>
												</div>
											</li>
											
										</ul>
									</div>
								</div>
							</div>
							
							

						</div>
					</div>
					<hr class="dubble-border"/>
				</div>
				<div class="social-media">
					<div class="container">
						<div class="row">
							<div class="col-xs-12 col-sm-6">
								<div class="paypal social-icon">
									<ul>
										<li><a href="#"><i class="fa fa-cc-visa"></i></a></li>
										<li><a href="#"><i class="fa fa-cc-mastercard"></i></a></li>
										<li><a href="#"><i class="fa fa-cc-paypal"></i></a></li>
										<li><a href="#"><i class="fa fa-cc-discover"></i></a></li>
										<li><a href="#"><i class="fa fa-cc-stripe"></i></a></li>
									</ul>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6">
								<div class="social-icon">
									<ul class="floatright">
										<li class="res-mar"><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-instagram"></i></a></li>
										<li><a href="#"><i class="fa fa-soundcloud"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- footer-top area end -->
			<!-- footer-bottom area start -->
			<div class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-center">
							<p>&copy; 2019 Montreal Gentleman. All Rights Reserved.</p>
						</div>
					</div>
				</div>
			</div>
			<!-- footer-bottom area end -->
		</footer>
        <!-- footer section end --><?php /**PATH F:\wamp64\www\mont\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>