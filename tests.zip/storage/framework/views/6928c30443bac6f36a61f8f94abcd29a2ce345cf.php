<div class="profile-sidebar">
        <!-- SIDEBAR USERPIC -->
        <div class="profile-userpic">
            <img src="<?php echo e(asset('uploads/avatars/' . $user->avatar)); ?>" alt="<?php echo e($user->name); ?>" class="img-responsive" />
        </div>
        <!-- END SIDEBAR USERPIC -->
        <!-- SIDEBAR USER TITLE -->
        <div class="profile-usertitle">
            <div class="profile-usertitle-name">
                <?php echo e($user->name); ?>

            </div>
        </div>
        <!-- END SIDEBAR USER TITLE -->
        
        <!-- SIDEBAR MENU -->
        <div class="profile-usermenu">
            <ul class="nav">
                <li class="<?php echo e($routename == 'my-account' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('my-account')); ?>">
                    <i class="glyphicon glyphicon-pencil"></i>
                    Account Settings </a>
                </li>

                <li class="<?php echo e($routename == 'my-profile' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('my-profile')); ?>">
                    <i class="glyphicon glyphicon-user"></i>
                    Profile Detail</a>
                </li>
                <li class="<?php echo e($routename == 'my-gallery' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('my-gallery')); ?>">
                    <i class="glyphicon glyphicon-picture"></i>
                    Gallery</a>
                </li>	
                <li class="<?php echo e($routename == 'my-booking' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('my-booking')); ?>">
                    <i class="glyphicon glyphicon-file"></i>
                    Booking</a>
                </li>						
                
            </ul>
        </div>
        <!-- END MENU -->
    </div><?php /**PATH D:\home\ssquares.co.in\subdomains\montreal\resources\views/frontend/user/profilenav.blade.php ENDPATH**/ ?>