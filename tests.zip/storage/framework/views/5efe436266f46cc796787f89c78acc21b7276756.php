<?php $__env->startSection('pagetitle'); ?>
        <!-- pages-title-start -->
        <section class="contact-img-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="con-text">
                            <h2 class="page-title">Login</h2>
                            <p><a href="#">Home</a> | Login</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- pages-title-end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- login content section start -->
		<div class="login-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-xs-12 col-md-offset-3">
                            <div class="tb-login-form ">
                                <h5 class="tb-title">Login</h5>
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <p class="checkout-coupon top log a-an">
                                        <label for="email"><?php echo e(__('E-Mail Address')); ?> <em>*</em></label>
                                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    <p class="checkout-coupon top-down log a-an">
                                        <label for="password"><?php echo e(__('Password')); ?></label>
                                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
        
                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    <div class="forgot-password1">
                                        <label class="inline2"><?php echo e(__('Remember Me')); ?> <em>*</em>
                                        </label>
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                    <?php endif; ?>
                                    </div>
                                    <p class="login-submit5">
                                            <button type="submit" class="btn btn-primary kbtn">
                                                    <?php echo e(__('Login')); ?>

                                                </button>
                                    </p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- login  content section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montrealgents\resources\views/auth/login.blade.php ENDPATH**/ ?>