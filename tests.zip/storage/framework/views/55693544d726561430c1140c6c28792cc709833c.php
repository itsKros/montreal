<?php
 $routename = Route::currentRouteName();
?>



<?php $__env->startSection('css'); ?>
<style>
div#example_wrapper {
    margin-top: 50px;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagetitle'); ?>
        <!-- pages-title-start -->
        <section class="contact-img-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="con-text">
                            <h2 class="page-title">My Account</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- pages-title-end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="profile"class="container">
    <div class="row profile">
		<div class="col-md-3">
            <?php echo $__env->make('frontend.user.profilenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="col-md-9 profile-content">

			<p class="pro-welcome">Hello <strong><?php echo e($user->name); ?></strong> (not <strong><?php echo e($user->name); ?></strong>? <a href="<?php echo e(route('logout')); ?>" class="link" data-toggle="tooltip" title="Logout" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>)
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
					<?php echo csrf_field(); ?>
				</form>From your account dashboard you can edit your account and profile details.
            </p>

            <table id="bo" class="table table-striped table-responsive table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Package</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($bookings)): ?>
                            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($booking->client_name); ?></td>
                                    <td><?php echo e($booking->client_email); ?></td>
                                    <td><?php echo e($booking->client_phone); ?></td>
                                    <td><?php echo e($booking->package); ?></td>
                                    <td>
                                        <?php
                                                $input = $booking->date;
                                                $date = strtotime($input);
                                                echo date('d M Y', $date);

                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $input = $booking->time;
                                            $time = strtotime($input);
                                            echo date('h:00 A', $time);

                                        ?>
                                    </td>
                                    <td><?php echo e($booking->address); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr><td>No Bookings</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('#bo').DataTable({
          responsive: true
        });
    } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\home\ssquares.co.in\subdomains\montreal\resources\views/frontend/user/mybooking.blade.php ENDPATH**/ ?>