<?php
 $routename = Route::currentRouteName();
?>



<?php $__env->startSection('css'); ?>
<style>
.form-group.fe{margin-bottom: 10px !important;}
.btn-sm.kbtn{padding: 10px 15px;}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagetitle'); ?>
        <!-- pages-title-start -->
        <section class="contact-img-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="con-text">
                            <h2 class="page-title">My Account</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- pages-title-end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="profile"class="container">
    <div class="row profile">
		<div class="col-md-3">
                <?php echo $__env->make('frontend.user.profilenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
		<div class="col-md-9 profile-content">
			<?php echo $__env->make('frontend.msgs.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<p class="pro-welcome">Hello <strong><?php echo e($user->name); ?></strong> (not <strong><?php echo e($user->name); ?></strong>? <a href="<?php echo e(route('logout')); ?>" class="link" data-toggle="tooltip" title="Logout" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>) 
				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						<?php echo csrf_field(); ?>
				</form>From your account dashboard you can edit your account and profile details.
            </p>
            <form method="post" class="form-horizontal" action="<?php echo e(route('galleryfeatured')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="col-md-6">
                    <div class="form-group fe">
                        <label for="featuredimage" class="control-label">Add Featured Image</label>
                        <input type="file" class="form-control" id="featuredimage" name="featuredimage"">
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="<?php echo e(asset('uploads/featuredimages/' . $user->featuredimage)); ?>" alt="<?php echo e($user->name); ?>" class="userfeatured"/>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-sm kbtn" value="Udpate">
                    </div>
                </div>
            </form>
            
            <div class="col-md-6 ">
                <form method="post" class="form-horizontal" action="<?php echo e(route('gallery.store')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-md-12" style="padding:0;">
                        <div class="form-group fe">
                            <label for="galleryitem" class="control-label">Gallery Image</label>
                            <input type="file" class="form-control" id="galleryitem" name="galleryitem"">
                        </div>
                    </div>
                    
                    <div class="col-md-12" style="padding:0;">
                        <div class="form-group">
                            <input type="submit" class="btn btn-primary btn-sm kbtn" value="Add Gallery Item">
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-6 ">
                <?php $__currentLoopData = $galleryitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 gall-thumb">
                        <form action="<?php echo e(route('gallery.destroy', ['id'=>$galleryitem->id])); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button class="btn btn-danger btn-xs" type="submit"><i class="fa fa-close"></i></button>
                        </form>
                    <img src="<?php echo e(asset('uploads/galleries/' . $galleryitem->galleryitem)); ?>" alt="" class="img-responsive thumb"/>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\home\ssquares.co.in\subdomains\montreal\resources\views/frontend/user/mygallery.blade.php ENDPATH**/ ?>