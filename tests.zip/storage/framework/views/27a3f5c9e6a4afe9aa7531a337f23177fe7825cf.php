<?php $__env->startSection('css'); ?>
<style>
.nivo-directionNav {
    display: none;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- slider-section-start -->
        <section class="slider-main-area">
            <div class="main-slider an-si">
                <div class="bend niceties preview-2 hm-ver-1">
                    <div id="ensign-nivoslider-2" class="slides">
                        <img src="<?php echo e(asset('frontend/img/slider/1.png')); ?>" alt="" title="#slider-direction-3"  />
                        <!-- <img src="<?php echo e(asset('frontend/img/slider/2.png')); ?>" alt="" title="#slider-direction-1"  /> -->
                    </div>
                    <!-- direction 1 -->
                    <div id="slider-direction-3" class="t-cn slider-direction Builder">
                        <div class="slide-all">
                            <!-- layer 1 -->
                            <div class="layer-1">
                                <h2 class="title0">Meet</h2>
                            </div>
                            <!-- layer 2 -->
                            <div class="layer-2">
                                <h2 class="title6">Antoine</h2>
                            </div>

                            <!-- layer 3 -->
                            <div class="layer-3">
                                <a class="min1" href="<?php echo e(route('model.show',['id'=> '13'])); ?>">View Profile Now</a>
                            </div>
                        </div>
                    </div>
                    <!-- <div id="slider-direction-1" class="t-cn slider-direction Builder">
                        <div class="slide-all slide2">
                             <!-- layer 1 -->
                             <!-- <div class="layer-1">
                                <h2 class="title0">Meet</h2>
                            </div> -->
                            <!-- layer 2 -->
                            <!-- <div class="layer-2">
                                <h2 class="title6">Vin Armani</h2>
                            </div> -->

                            <!-- layer 3 -->
                            <!-- <div class="layer-3">
                                <a class="min1" href="#">View Profile Now</a>
                            </div> -->
                        <!--</div>
                    </div> -->
			          </div>
            </div>
        </section>
		<!-- slider section end -->

        <!-- new-products section start -->
        <section class="new-products single-products section-padding-top section-padding-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="section-title">
                                <h3><?php echo e($homeinfo->welcometitle); ?></h3>
                                <div class="section-icon">
                                    <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                </div>
                                <div class="wpara">
                                        <?php echo $homeinfo->welcomecontent; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                      <?php if(count($users)>=4): ?>
                        <div id="new-products" class="owl-carousel product-slider owl-theme">
                            <?php if(count($users)): ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xs-12">
                                        <div class="single-product">
                                            <div class="product-img">
                                                <!-- <a href="/model/<?php echo e($user->id); ?>"> -->
                                                <a href="<?php echo e(url('/model/'. $user->id)); ?>">
                                                    <img src="<?php echo e(asset('uploads/featuredimages/' . $user->featuredimage)); ?>" alt="<?php echo e($user->name); ?>" />
                                                </a>
                                            </div>
                                            <div class="product-dsc">
                                                <h3><a href="/model/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a></h3>
                                                <div class="star-price">
                                                    <span class="price-left">View Profile</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <em>No Models</em>
                            <?php endif; ?>

                            <!-- <div class="col-xs-12">
                                <div class="single-product">
                                    <div class="product-img">
                                        <div class="pro-type">
                                            <span>sale</span>
                                        </div>
                                        <a href="#">
                                            <img src="<?php echo e(asset('frontend/img/products/2.jpg')); ?>" alt="Product Title" />
                                        </a>
                                    </div>
                                    <div class="product-dsc">
                                        <h3><a href="#">Jon Doe</a></h3>
                                        <div class="star-price">
                                            <span class="price-left">View Profile</span>
                                        </div>
                                    </div>
                                </div>
                            </div> -->

                        </div>
                      <?php else: ?>
                      <div class="col-md-6">
                        <img class="img-responsive" src="<?php echo e(asset('frontend/img/half-1.jpg')); ?>" />
                      </div>
                      <div class="col-md-6">
                        <img class="img-responsive" src="<?php echo e(asset('frontend/img/half-2.jpg')); ?>" />
                      </div>
                      <?php endif; ?>
                    </div>
                </div>
        </section>
        <!-- new-products section end -->

        <!-- Edge to Edge section start -->
        <section class="sectione">
            <div class="container-fluid e2e" style="border-top: 1px solid #cecece;">
                <div class="row">
                    <div class="col-md-6 edi first"></div>
                    <div class="col-md-6 edc">
                        <div class="section-title">
                            <h3><?php echo e($homeinfo->ete_first_title); ?></h3>
                            <div class="section-icon">
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                            </div>
                        </div>

                        <div  class="wpara nor">
                                <?php echo $homeinfo->ete_first_content; ?>

                        </div>

                        <div class="btnw">
                            <a href="<?php echo e(route('models')); ?>" class="btn btn-lg btn-primary kbtn">View All Montreal Gentleman</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Edge to Edge section end -->


        <!-- Edge to Edge section start -->
        <section class="sectione">
            <div class="container-fluid e2e">
                <div class="row">
                    <div class="col-md-6 edc">
                        <div class="section-title">
                            <h3><?php echo e($homeinfo->ete_second_title); ?></h3>
                            <div class="section-icon">
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                            </div>
                        </div>

                        <div  class="wpara nor">
                                <?php echo $homeinfo->ete_second_content; ?>


                        </div>

                        <div class="btnw">
                            <a href="<?php echo e(route('services')); ?>" class="btn btn-lg btn-primary kbtn">Read More</a>
                        </div>
                    </div>

                    <div class="col-md-6 edi second"></div>
                </div>
            </div>
        </section>
        <!-- Edge to Edge section end -->


        <!-- testimonials section start -->
        <section class="testimonials stripe-parallax-bg" data-parallax-speed="0.5">
            <div class="overlay"></div>
            <div class="re-testimonials">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="section-title re-section-title">
                                <h3>TESTIMONIALS</h3>
                                <div class="section-icon re-section1">
                                    <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-10 col-text-center text-center">
                            <div id="testimonials" class="re-owl-carousel2 owl-carousel product-slider owl-theme">
                                <?php if(count($testimonials)): ?>
                                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="single-testimonial">
                                            <div class="testimonial-dsc">
                                                <p><?php echo e($testimonial->desc); ?></p>
                                            </div>
                                            <div class="testimonial-img">
                                                <a href="#">
                                                    <img src="<?php echo e(asset('uploads/testimonials/' . $testimonial->author_img)); ?>" alt="<?php echo e($testimonial->author_name); ?>" class="userfeatured"/>
                                                </a>
                                                <h4><a href="#"><?php echo e($testimonial->author_name); ?></a></h4>
                                                <span><?php echo e($testimonial->author_desig); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        No Testimonials
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonials section end -->


        <!-- Featured section start -->
        <section class="">
            <div class="brand-logo">
                <div class="barnd-bg">
                    <div class="container">

                            <div class="row">
                                    <div class="col-xs-12">
                                        <div class="section-title">
                                            <h3>Featured In</h3>
                                            <div class="section-icon">
                                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        <div class="row text-center">
                            <div id="brand-logo" class="re-owl-carousel21 owl-carousel product-slider owl-theme">
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/1.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/2.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/3.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/4.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/5.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/6.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/1.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                                <div class="col-xs-12">
                                    <div class="single-brand">
                                        <a href="#"><img src="<?php echo e(asset('frontend/img/brand/3.png')); ?>" alt="" /></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- brand section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montrealgents\resources\views/frontend/home.blade.php ENDPATH**/ ?>