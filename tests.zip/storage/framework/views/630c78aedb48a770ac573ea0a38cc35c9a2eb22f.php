<?php
 $routename = Route::currentRouteName();
?>



<?php $__env->startSection('css'); ?>
<style>


</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagetitle'); ?>
        <!-- pages-title-start -->
        <section class="contact-img-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="con-text">
                            <h2 class="page-title">Montreal Gentlemen</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- pages-title-end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row models">
        <?php if(count($users)): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
            
                    <div class="single-product">
                        <div class="product-img">
                            <a href="<?php echo e(url('/model/'. $user->id)); ?>">
                                <img src="<?php echo e(asset('uploads/featuredimages/' . $user->featuredimage)); ?>" alt="Product Title" />
                            </a>
                        </div>
                        <div class="product-dsc">
                            <h3><a href="#"><?php echo e($user->name); ?></a></h3>
                            <div class="star-price">
                                <span class="price-left">View Profile</span>
                            </div>
                        </div>
                    </div>
                

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                        <em>No Models</em> 
            <?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\montreal\resources\views/frontend/user/index.blade.php ENDPATH**/ ?>